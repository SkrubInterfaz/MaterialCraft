══════════════════════════════════════════════════════════════════════════════
| 888888ba  oo                   dP          888888ba                        |
|  88    `8b                      88          88    `8b                      |
| a88aaaa8P' dP 88d888b. .d8888b. 88 .d8888b. 88     88 88d888b. d888888b    |
|  88        88 88'  `88 88'  `88 88 Y8ooooo. 88     88 88'  `88    .d8P'    |
|  88        88 88    88 88.  .88 88       88 88    .8P 88    88  .Y8P       |
|  dP        dP dP    dP `8888P88 dP `88888P' 8888888P  dP    dP d888888P    |
|                             .88                                            |
|                         d8888P                                             |
══════════════════════════════════════════════════════════════════════════════

Merci de laisser les crédits au auteur dans le footer du site sous quoi l'auteur se reserve le doit de faire revoquer l'utilisation de celui-ci

══════════════════════════════════════════════════════════════════════════════

Pour la version: 1.7.3
Version de développement: 1.0_beta

Commentaires: []
Crédits:
    MaterializeCSS: https://materializecss.com/
    jQuery: https://jquery.com/
    typed.js: https://github.com/mattboldt/typed.js/
    FontAwesome: https://fontawesome.com/
    Material.io: https://material.io/resources/icons/
    Fonts: https://fonts.google.com/
    Images: https://fr-minecraft.net/
    (Les images par default ne sont mise qu'à titre d'exemple)

══════════════════════════════════════════════════════════════════════════════

Discord Tag (Pour d'éventuelle(s) question(s)):
PinglsDzn#1702

Pour m'offrir un café:
>> https://www.buymeacoffee.com/PinglsDzn

══════════════════════════════════════════════════════════════════════════════
  a88888b.                   .8888b   dP   8888ba.88ba           dP   dP   dP          dP                oo   dP               d88     d88888P
d8'   `88                   88   "   88   88  `8b  `8b          88   88   88          88                     88                88         d8'
88        88d888b. .d8888b. 88aaa  d8888P 88   88   88 dP    dP 88  .8P  .8P .d8888b. 88d888b. .d8888b. dP d8888P .d8888b.     88        d8'
88        88'  `88 88'  `88 88       88   88   88   88 88    88 88  d8'  d8' 88ooood8 88'  `88 Y8ooooo. 88   88   88ooood8     88       d8'
Y8.   .88 88       88.  .88 88       88   88   88   88 88.  .88 88.d8P8.d8P  88.  ... 88.  .88       88 88   88   88.  ...     88  dP  d8'
 Y88888P' dP       `88888P8 dP       dP   dP   dP   dP `8888P88 8888' Y88'   `88888P' 88Y8888' `88888P' dP   dP   `88888P'    d88P 88 d8'
                                                            .88
                                                        d8888P
══════════════════════════════════════════════════════════════════════════════
<div class="container bgcontainer" style="min-height: 500px;height: 100%;">
    <div class="section">
        <div class="card"
            style="display: block; margin-left: 20%; text-align: center; margin-right: 20%; margin-top: 10%;padding-bottom: 2%;">
            <h4 class="card-title"><?=$titre;?></h4>
            <h6 class="card-subtitle mb-2 text-muted"><?=$type;?></h6>
                <hr/>
            <div class="card-content">
                <p class="card-text"><?=$contenue;?></p>
            <br/>
            <div class="card-action">
            <a href="index.php" class="btn waves-effect green">Retourner à
                    l'accueil</a>
            </div>
            </div>
        </div>
    </div>
</div>